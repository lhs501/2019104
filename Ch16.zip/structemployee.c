// file: structemployee.c
#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>

//�ڱ����� ����ü ����
typedef struct employee {
	int id;
	char *name;
	int salary;
	struct employee *next;
} employee;

int main(void)
{
	employee *one = (employee *)malloc(sizeof(employee));
	employee *you = (employee *)malloc(sizeof(employee));

	one->id = 20146729;
	one->salary = 1000000;
	one->name = (char *)malloc(strlen("�Źξ�") + 1);
	strcpy(one->name, "�Źξ�");
	you->id = 20146730;
	you->salary = 2000000;
	you->name = (char *)malloc(strlen("����ȣ") + 1);
	strcpy(you->name, "����ȣ");

	you->next = one;
	printf("%d %s %d\n", you->id, you->name, you->salary);
	printf("%d %s %d\n", one->id, one->name, one->salary);
	printf("%d %s %d\n", you->next->id, you->next->name, you->next->salary);

	//�����޸� �Ҵ� ����
	free(one);
	free(you);

	return 0;
}
